# Environment Variables

- `OPENAI_ORG`
- `OPENAI_TOKEN`
- `AI_GETTER_SAVE_PATH`
- `AI_GETTER_S3_BUCKET`

# Credentials

Make sure you have credentials in an `~/.aws` directory if you want to upload any outputs to S3.
